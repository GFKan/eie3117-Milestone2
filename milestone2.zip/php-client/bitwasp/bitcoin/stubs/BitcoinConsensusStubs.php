<?php

namespace {

    /**
     * @return int
     */
    function bitcoinconsensus_version() {
    }

    /**
     * @param $scriptPubKey
     * @param $transaction
     * @param $nInput
     * @param $flags
     * @param $error
     * @return bool
     */
    function bitcoinconsensus_verify_script($scriptPubKey, $transaction, $nInput, $flags, &$error) {

    }
}

