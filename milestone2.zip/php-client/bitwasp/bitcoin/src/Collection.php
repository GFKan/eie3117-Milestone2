<?php

namespace BitWasp\Bitcoin;

abstract class Collection implements CollectionInterface
{

}
