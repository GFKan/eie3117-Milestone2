<?php

namespace BitWasp\Bitcoin\Exceptions;

class BlockPowError extends \Exception
{

}
