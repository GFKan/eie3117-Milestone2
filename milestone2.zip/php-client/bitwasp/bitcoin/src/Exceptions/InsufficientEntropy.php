<?php

namespace BitWasp\Bitcoin\Exceptions;

class InsufficientEntropy extends \Exception
{
}
