<?php

namespace BitWasp\Bitcoin\Exceptions;

class SignatureNotCanonical extends \Exception
{

}
