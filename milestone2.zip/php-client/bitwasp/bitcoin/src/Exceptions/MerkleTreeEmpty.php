<?php

namespace BitWasp\Bitcoin\Exceptions;

class MerkleTreeEmpty extends \Exception
{
}
