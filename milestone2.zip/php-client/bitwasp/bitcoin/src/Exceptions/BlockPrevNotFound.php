<?php

namespace BitWasp\Bitcoin\Exceptions;

class BlockPrevNotFound extends \Exception
{

}
