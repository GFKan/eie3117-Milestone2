<?php

namespace BitWasp\Bitcoin\Exceptions;

class ScriptStackException extends \Exception
{
}
