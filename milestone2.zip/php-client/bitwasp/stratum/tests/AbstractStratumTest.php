<?php

namespace BitWasp\Stratum\Tests;

abstract class AbstractStratumTest extends \PHPUnit_Framework_TestCase
{

}
