<?php

namespace BitWasp\Buffertools\Tests;

abstract class BinaryTest extends \PHPUnit_Framework_TestCase
{

}
