<?php

namespace BlockCypher\Rest;

/**
 * Interface IResource
 *
 * @package BlockCypher\Rest
 */
interface IResource
{
}
